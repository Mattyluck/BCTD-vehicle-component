package main

import (
	"fmt"
	"time"
	"zk_eq_blockchain/pkg"
)

func main() {
	Test2()
	Test1()
}

//一个区块10笔交易，一共跑50个区块，记录每个区块生成的交易数、证明大小，证明生成时间
//一个区块20笔交易，一共跑50个区块，记录每个区块生成的交易数、证明大小，证明生成时间
//...
func Test2() {
	// 测试区块内笔数
	height := 50
	txsCount := []uint{10, 20, 30, 40, 50}
	for i := 0; i < len(txsCount); i++ {
		txs := txsCount[i]

		for h := 0; h < height; h++ {
			var proofs [][]byte
			var vks [][]byte
			beginTime := time.Now()
			for j := 0; j < int(txs); j++ {
				proof, vk := pkg.GenerateProve(uint(j))
				proofs = append(proofs, proof)
				vks = append(vks, vk)
			}
			//获取占用的毫秒数
			proofTime := time.Now().Sub(beginTime).Milliseconds()

			bt1 := time.Now()
			proofLen := 0
			for j := 0; j < int(txs); j++ {
				_, err := pkg.VerifyProof(uint(j), vks[j], proofs[j])
				if err != nil {
					panic(err)
				}
				proofLen += len(proofs[j])
			}

			verifyTime := time.Now().Sub(bt1).Milliseconds()
			fmt.Printf("高度为：%d, 一个区块内的交易数：%d, 证明总大小：%d (Byte), 生成证明的时间为: %d ms, 验证时间为：%d\n",h+1,  txs, proofLen, proofTime, verifyTime)
		}
	}

}

//一个区块10笔交易，打印区块算法信息
//一个区块20笔交易，打印区块算法信息
//一个区块30笔交易，打印区块算法信息
func Test1() {
	// 测试区块内笔数
	//txsCount := []uint{1000, 1200, 1400, 1600, 1800, 2000, 2200, 2400, 2600, 2800, 3000}
	txsCount := []uint{10, 12, 14, 16}
	for i := 0; i < len(txsCount); i++ {
		var proofs [][]byte
		var vks [][]byte

		beginTime := time.Now()
		txs := txsCount[i]
		for j := 0; j < int(txs); j++ {
			proof, vk := pkg.GenerateProve(uint(j))
			proofs = append(proofs, proof)
			vks = append(vks, vk)
		}
		//获取占用的毫秒数
		proofTime := time.Now().Sub(beginTime).Milliseconds()

		bt1 := time.Now()
		proofLen := 0
		for j := 0; j < int(txs); j++ {
			_, err := pkg.VerifyProof(uint(j), vks[j], proofs[j])
			if err != nil {
				panic(err)
			}
			proofLen += len(proofs[j])
		}

		verifyTime := time.Now().Sub(bt1).Milliseconds()
		fmt.Printf("一个区块内的交易数：%d, 证明总大小：%d (Byte), 生成证明的时间为: %d ms, 验证时间为：%d\n", txs, proofLen, proofTime, verifyTime)
	}
}