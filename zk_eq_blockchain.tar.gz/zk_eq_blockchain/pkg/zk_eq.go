package pkg

import (
	"bytes"
	"github.com/consensys/gnark-crypto/ecc"
	"github.com/consensys/gnark/backend/groth16"
	"github.com/consensys/gnark/frontend"
	"github.com/consensys/gnark/frontend/cs/r1cs"
)


//cmpCircuit 为等值电路
type cmpCircuit struct {
	A frontend.Variable
	B frontend.Variable `gnark:",public"`
	R frontend.Variable
}

//电路对输入的A、B进行获取比较
func (circuit *cmpCircuit) Define(api frontend.API) error {
	r := api.Cmp(circuit.A, circuit.B)
	api.AssertIsEqual(r, circuit.R)
	return nil
}

//生成电路、proof、verifyKey
func GenerateProve(value uint)  ([]byte, []byte){
	// 外部系统生成零知识证明电路，编译电路
	var circuit cmpCircuit
	ccs, err := frontend.Compile(ecc.BN254, r1cs.NewBuilder, &circuit)
	if err != nil {
		panic(err)
	}
	// 根据编译电路生成proofKey
	pk, vk, err := groth16.Setup(ccs)
	if err != nil {
		panic(err)
	}

	// witness definition
	assignment :=  cmpCircuit{
		A: value,
		B: value,
		R: 0,
	}

	witness, err := frontend.NewWitness(&assignment, ecc.BN254)
	if err != nil {
		panic(err)
	}

	proof, err := groth16.Prove(ccs, pk, witness)
	if err != nil {
		panic(err)
	}
	var proofBuffer bytes.Buffer
	proofBuffer.Reset()
	proof.WriteRawTo(&proofBuffer)
	proofBuffer.Bytes()

	var vkBuffer bytes.Buffer
	vkBuffer.Reset()
	vk.WriteRawTo(&vkBuffer)
	vkBuffer.Bytes()

	//proof, verifyKey
	return proofBuffer.Bytes(), vkBuffer.Bytes()
}

func VerifyProof(value uint, verifyKey []byte, publicWitness []byte) (bool, error) {
	assignment1 :=  cmpCircuit{
		B:     value,
	}
	publicWitness1,err := frontend.NewWitness(&assignment1, ecc.BN254, frontend.PublicOnly())
	if err != nil {
		return false, err
	}

	proof := groth16.NewProof(ecc.BN254)
	proof.ReadFrom(bytes.NewBuffer(publicWitness))

	vk := groth16.NewVerifyingKey(ecc.BN254)
	vk.ReadFrom(bytes.NewBuffer(verifyKey))

	err = groth16.Verify(proof, vk, publicWitness1)
	if err != nil {
		return false, err
	}
	return true, nil
}
